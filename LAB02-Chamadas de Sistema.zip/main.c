#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *file;
    char buffer[128];

    //abrindo o aquivo lab2_ex1.txt
    file = fopen("lab2_ex1.txt", "r");

    //verificação para ver se o arquivo esta vazio
    if (file == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        return 1;
    }

    //lendo conteudo para o buffer 
    size_t bytesRead = fread(buffer, 1, sizeof(buffer) - 1, file);

    
    buffer[bytesRead] = '\0';

    
    printf("Conteúdo do arquivo:\n%s\n", buffer);

    
    fclose(file);

    return 0;
}
